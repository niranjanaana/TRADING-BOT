"""
Binance Futures Testnet REST API client.

Handles:
  - HMAC-SHA256 request signing
  - Authenticated and public endpoint calls
  - Structured logging of every request and response
  - Uniform exception wrapping
"""

from __future__ import annotations

import hashlib
import hmac
import time
from typing import Any
from urllib.parse import urlencode

import requests

from .logging_config import get_logger

logger = get_logger("client")

TESTNET_BASE_URL = "https://testnet.binancefuture.com"
DEFAULT_TIMEOUT = 10  # seconds


class BinanceAPIError(Exception):
    """Raised when the Binance API returns an error response."""

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"Binance API error {code}: {message}")


class BinanceClient:
    """
    Thin wrapper around the Binance USDT-M Futures REST API (testnet).

    Parameters
    ----------
    api_key:    Testnet API key
    api_secret: Testnet API secret
    base_url:   Override the default testnet base URL (useful for testing)
    timeout:    HTTP request timeout in seconds
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        base_url: str = TESTNET_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
    ) -> None:
        if not api_key or not api_secret:
            raise ValueError("api_key and api_secret must not be empty.")

        self._api_key = api_key
        self._api_secret = api_secret
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers.update(
            {
                "X-MBX-APIKEY": self._api_key,
                "Content-Type": "application/x-www-form-urlencoded",
            }
        )
        logger.debug("BinanceClient initialised (base_url=%s)", self._base_url)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _sign(self, params: dict) -> dict:
        """Append a signature to *params* (mutates and returns it)."""
        query_string = urlencode(params)
        signature = hmac.new(
            self._api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        params["signature"] = signature
        return params

    def _timestamp(self) -> int:
        return int(time.time() * 1000)

    def _handle_response(self, response: requests.Response) -> Any:
        """Parse the response and raise BinanceAPIError on non-2xx."""
        logger.debug(
            "HTTP %s %s | status=%s | body=%s",
            response.request.method,
            response.url,
            response.status_code,
            response.text[:500],
        )
        try:
            data = response.json()
        except ValueError:
            response.raise_for_status()
            return response.text

        if isinstance(data, dict) and "code" in data and data["code"] != 200:
            raise BinanceAPIError(data["code"], data.get("msg", "unknown error"))

        response.raise_for_status()
        return data

    # ------------------------------------------------------------------
    # Public API calls
    # ------------------------------------------------------------------

    def get_server_time(self) -> dict:
        """Ping the API and return server time (unauthenticated)."""
        url = f"{self._base_url}/fapi/v1/time"
        logger.debug("GET %s", url)
        resp = self._session.get(url, timeout=self._timeout)
        return self._handle_response(resp)

    def get_exchange_info(self, symbol: str | None = None) -> dict:
        """Return exchange info, optionally filtered to one symbol."""
        url = f"{self._base_url}/fapi/v1/exchangeInfo"
        params = {"symbol": symbol} if symbol else {}
        logger.debug("GET %s params=%s", url, params)
        resp = self._session.get(url, params=params, timeout=self._timeout)
        return self._handle_response(resp)

    def get_account(self) -> dict:
        """Return futures account information (signed)."""
        url = f"{self._base_url}/fapi/v2/account"
        params = self._sign({"timestamp": self._timestamp()})
        logger.debug("GET %s", url)
        resp = self._session.get(url, params=params, timeout=self._timeout)
        return self._handle_response(resp)

    def place_order(self, **params) -> dict:
        """
        Place a new futures order.

        Accepted keyword arguments mirror the Binance FAPI /order endpoint:
          symbol, side, type, quantity, price, timeInForce, stopPrice, etc.

        Returns the raw API response dict.
        """
        url = f"{self._base_url}/fapi/v1/order"
        params["timestamp"] = self._timestamp()
        signed = self._sign(params)

        logger.info(
            "Placing order | symbol=%s side=%s type=%s qty=%s price=%s",
            params.get("symbol"),
            params.get("side"),
            params.get("type"),
            params.get("quantity"),
            params.get("price", "N/A"),
        )
        logger.debug("POST %s | params=%s", url, {k: v for k, v in signed.items() if k != "signature"})

        resp = self._session.post(
            url,
            data=signed,
            timeout=self._timeout,
        )
        result = self._handle_response(resp)
        logger.info(
            "Order placed | orderId=%s status=%s executedQty=%s avgPrice=%s",
            result.get("orderId"),
            result.get("status"),
            result.get("executedQty"),
            result.get("avgPrice", "N/A"),
        )
        return result

    def cancel_order(self, symbol: str, order_id: int) -> dict:
        """Cancel an open order by orderId."""
        url = f"{self._base_url}/fapi/v1/order"
        params = self._sign(
            {
                "symbol": symbol,
                "orderId": order_id,
                "timestamp": self._timestamp(),
            }
        )
        logger.info("Cancelling order | symbol=%s orderId=%s", symbol, order_id)
        resp = self._session.delete(url, params=params, timeout=self._timeout)
        return self._handle_response(resp)

    def get_open_orders(self, symbol: str | None = None) -> list:
        """Return open orders, optionally filtered by symbol."""
        url = f"{self._base_url}/fapi/v1/openOrders"
        params: dict = {"timestamp": self._timestamp()}
        if symbol:
            params["symbol"] = symbol
        params = self._sign(params)
        logger.debug("GET open orders | symbol=%s", symbol)
        resp = self._session.get(url, params=params, timeout=self._timeout)
        return self._handle_response(resp)
