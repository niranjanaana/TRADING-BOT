"""
Order placement logic for Binance Futures Testnet.

This module translates validated user parameters into the exact
API parameters required by each order type, then delegates to
the BinanceClient for the actual HTTP call.
"""

from __future__ import annotations

from typing import Any

from .client import BinanceClient, BinanceAPIError
from .logging_config import get_logger

logger = get_logger("orders")


def _format_response(resp: dict) -> dict:
    """
    Extract and return the key fields from an order response for display.
    Returns all fields if the expected keys are absent.
    """
    return {
        "orderId": resp.get("orderId"),
        "symbol": resp.get("symbol"),
        "side": resp.get("side"),
        "type": resp.get("type"),
        "status": resp.get("status"),
        "origQty": resp.get("origQty"),
        "executedQty": resp.get("executedQty"),
        "avgPrice": resp.get("avgPrice") or resp.get("price"),
        "price": resp.get("price"),
        "stopPrice": resp.get("stopPrice"),
        "timeInForce": resp.get("timeInForce"),
        "updateTime": resp.get("updateTime"),
    }


def place_market_order(
    client: BinanceClient,
    symbol: str,
    side: str,
    quantity: float,
) -> dict:
    """
    Place a MARKET order.

    Parameters
    ----------
    client:   Authenticated BinanceClient instance
    symbol:   Trading pair, e.g. 'BTCUSDT'
    side:     'BUY' or 'SELL'
    quantity: Contract quantity
    """
    logger.info("Preparing MARKET order | symbol=%s side=%s qty=%s", symbol, side, quantity)
    resp = client.place_order(
        symbol=symbol,
        side=side,
        type="MARKET",
        quantity=quantity,
    )
    return _format_response(resp)


def place_limit_order(
    client: BinanceClient,
    symbol: str,
    side: str,
    quantity: float,
    price: float,
    time_in_force: str = "GTC",
) -> dict:
    """
    Place a LIMIT order.

    Parameters
    ----------
    client:        Authenticated BinanceClient instance
    symbol:        Trading pair, e.g. 'BTCUSDT'
    side:          'BUY' or 'SELL'
    quantity:      Contract quantity
    price:         Limit price
    time_in_force: 'GTC' (default), 'IOC', or 'FOK'
    """
    logger.info(
        "Preparing LIMIT order | symbol=%s side=%s qty=%s price=%s tif=%s",
        symbol, side, quantity, price, time_in_force,
    )
    resp = client.place_order(
        symbol=symbol,
        side=side,
        type="LIMIT",
        quantity=quantity,
        price=price,
        timeInForce=time_in_force,
    )
    return _format_response(resp)


def place_stop_market_order(
    client: BinanceClient,
    symbol: str,
    side: str,
    quantity: float,
    stop_price: float,
) -> dict:
    """
    Place a STOP_MARKET order (bonus order type).

    Triggers a market order when the market price reaches *stop_price*.

    Parameters
    ----------
    client:     Authenticated BinanceClient instance
    symbol:     Trading pair, e.g. 'BTCUSDT'
    side:       'BUY' or 'SELL'
    quantity:   Contract quantity
    stop_price: The trigger price
    """
    logger.info(
        "Preparing STOP_MARKET order | symbol=%s side=%s qty=%s stopPrice=%s",
        symbol, side, quantity, stop_price,
    )
    resp = client.place_order(
        symbol=symbol,
        side=side,
        type="STOP_MARKET",
        quantity=quantity,
        stopPrice=stop_price,
    )
    return _format_response(resp)


def place_order(
    client: BinanceClient,
    *,
    symbol: str,
    side: str,
    order_type: str,
    quantity: float,
    price: float | None = None,
    time_in_force: str = "GTC",
) -> dict:
    """
    Dispatch to the correct order-type function based on *order_type*.
    This is the main entry-point called by the CLI layer.
    """
    order_type = order_type.upper()

    if order_type == "MARKET":
        return place_market_order(client, symbol, side, quantity)
    elif order_type == "LIMIT":
        if price is None:
            raise ValueError("Price is required for LIMIT orders.")
        return place_limit_order(client, symbol, side, quantity, price, time_in_force)
    elif order_type == "STOP_MARKET":
        if price is None:
            raise ValueError("Stop price (--price) is required for STOP_MARKET orders.")
        return place_stop_market_order(client, symbol, side, quantity, price)
    else:
        raise ValueError(f"Unsupported order type: {order_type}")
