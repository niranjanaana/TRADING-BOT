#!/usr/bin/env python3
"""
cli.py – Command-line interface for the Binance Futures Testnet Trading Bot.

Usage examples
--------------
# Market buy
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001

# Limit sell
python cli.py --symbol ETHUSDT --side SELL --type LIMIT --quantity 0.01 --price 2000

# Stop-market buy (bonus)
python cli.py --symbol BTCUSDT --side BUY --type STOP_MARKET --quantity 0.001 --price 95000

# Override credentials inline (or set env vars BINANCE_API_KEY / BINANCE_API_SECRET)
python cli.py --api-key <key> --api-secret <secret> --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001

# Verbose console output
python cli.py --log-level DEBUG --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import textwrap

import requests

from bot.client import BinanceClient, BinanceAPIError
from bot.logging_config import setup_logging, get_logger
from bot.orders import place_order
from bot.validators import validate_all

# ──────────────────────────────────────────────────────────────────────────────
# ANSI colour helpers (gracefully disabled on Windows / non-TTY)
# ──────────────────────────────────────────────────────────────────────────────
_USE_COLOUR = sys.stdout.isatty() and os.name != "nt"


def _c(text: str, code: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _USE_COLOUR else text


def green(t):  return _c(t, "32")
def red(t):    return _c(t, "31")
def yellow(t): return _c(t, "33")
def cyan(t):   return _c(t, "36")
def bold(t):   return _c(t, "1")


# ──────────────────────────────────────────────────────────────────────────────
# Argument parsing
# ──────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading_bot",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=textwrap.dedent(
            """\
            ╔══════════════════════════════════════════╗
            ║  Binance Futures Testnet  Trading Bot    ║
            ╚══════════════════════════════════════════╝

            Place MARKET, LIMIT, or STOP_MARKET orders on the
            Binance USDT-M Futures Testnet.

            Credentials are read from:
              1. --api-key / --api-secret flags
              2. BINANCE_API_KEY / BINANCE_API_SECRET environment variables
            """
        ),
    )

    # ── Credentials ──
    cred = parser.add_argument_group("credentials")
    cred.add_argument(
        "--api-key",
        metavar="KEY",
        default=os.getenv("BINANCE_API_KEY", ""),
        help="Testnet API key (or set BINANCE_API_KEY env var)",
    )
    cred.add_argument(
        "--api-secret",
        metavar="SECRET",
        default=os.getenv("BINANCE_API_SECRET", ""),
        help="Testnet API secret (or set BINANCE_API_SECRET env var)",
    )

    # ── Order parameters ──
    order = parser.add_argument_group("order parameters")
    order.add_argument(
        "--symbol", "-s",
        required=True,
        metavar="SYMBOL",
        help="Trading pair, e.g. BTCUSDT",
    )
    order.add_argument(
        "--side",
        required=True,
        choices=["BUY", "SELL", "buy", "sell"],
        metavar="SIDE",
        help="BUY or SELL",
    )
    order.add_argument(
        "--type", "-t",
        dest="order_type",
        required=True,
        choices=["MARKET", "LIMIT", "STOP_MARKET", "market", "limit", "stop_market"],
        metavar="TYPE",
        help="Order type: MARKET | LIMIT | STOP_MARKET",
    )
    order.add_argument(
        "--quantity", "-q",
        required=True,
        metavar="QTY",
        help="Order quantity (contracts)",
    )
    order.add_argument(
        "--price", "-p",
        default=None,
        metavar="PRICE",
        help="Limit price (required for LIMIT) or stop-trigger price (STOP_MARKET)",
    )
    order.add_argument(
        "--time-in-force",
        default="GTC",
        choices=["GTC", "IOC", "FOK"],
        metavar="TIF",
        help="Time-in-force for LIMIT orders (default: GTC)",
    )

    # ── Misc ──
    misc = parser.add_argument_group("misc")
    misc.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        metavar="LEVEL",
        help="Console log level (default: INFO; file always DEBUG)",
    )
    misc.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate inputs and print request summary without sending the order",
    )

    return parser


# ──────────────────────────────────────────────────────────────────────────────
# Display helpers
# ──────────────────────────────────────────────────────────────────────────────

def print_separator(char: str = "─", width: int = 56) -> None:
    print(char * width)


def print_request_summary(params: dict) -> None:
    print()
    print_separator("═")
    print(bold("  ORDER REQUEST SUMMARY"))
    print_separator("═")
    rows = [
        ("Symbol",    params["symbol"]),
        ("Side",      params["side"]),
        ("Type",      params["order_type"]),
        ("Quantity",  params["quantity"]),
        ("Price",     params["price"] if params["price"] is not None else "—"),
    ]
    for label, value in rows:
        print(f"  {cyan(f'{label:<12}')}{value}")
    print_separator()


def print_order_response(result: dict) -> None:
    print_separator("═")
    print(bold("  ORDER RESPONSE"))
    print_separator("═")
    fields = [
        ("Order ID",     result.get("orderId")),
        ("Symbol",       result.get("symbol")),
        ("Side",         result.get("side")),
        ("Type",         result.get("type")),
        ("Status",       result.get("status")),
        ("Orig Qty",     result.get("origQty")),
        ("Executed Qty", result.get("executedQty")),
        ("Avg Price",    result.get("avgPrice") or "—"),
        ("Limit Price",  result.get("price") or "—"),
        ("Stop Price",   result.get("stopPrice") or "—"),
        ("Time In Force",result.get("timeInForce") or "—"),
    ]
    for label, value in fields:
        col = (label + ":").ljust(22)
        if value not in (None, "—", "", "0", "0.00000000"):
            print("  " + cyan(col) + str(value))
        else:
            print("  " + col + yellow("—"))
    print_separator()


# ──────────────────────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────────────────────

def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    # Initialise logging before anything else
    setup_logging(args.log_level)
    logger = get_logger("cli")

    logger.debug("Raw CLI args: %s", vars(args))

    # ── 1. Validate inputs ──────────────────────────────────────────────────
    try:
        validated = validate_all(
            symbol=args.symbol,
            side=args.side,
            order_type=args.order_type,
            quantity=args.quantity,
            price=args.price,
        )
    except ValueError as exc:
        print(red(f"\n✗ Validation error: {exc}\n"))
        logger.error("Validation failed: %s", exc)
        return 1

    print_request_summary(validated)

    if args.dry_run:
        print(yellow("  DRY-RUN mode — order NOT sent.\n"))
        logger.info("Dry-run: order not placed.")
        return 0

    # ── 2. Check credentials ────────────────────────────────────────────────
    if not args.api_key or not args.api_secret:
        msg = (
            "API credentials are missing.\n"
            "  Set BINANCE_API_KEY and BINANCE_API_SECRET environment variables,\n"
            "  or pass --api-key and --api-secret flags."
        )
        print(red(f"\n✗ {msg}\n"))
        logger.error("Missing API credentials.")
        return 1

    # ── 3. Build client ─────────────────────────────────────────────────────
    try:
        client = BinanceClient(
            api_key=args.api_key,
            api_secret=args.api_secret,
        )
    except ValueError as exc:
        print(red(f"\n✗ Client init error: {exc}\n"))
        logger.error("Client init failed: %s", exc)
        return 1

    # ── 4. Place order ──────────────────────────────────────────────────────
    try:
        result = place_order(
            client,
            symbol=validated["symbol"],
            side=validated["side"],
            order_type=validated["order_type"],
            quantity=validated["quantity"],
            price=validated["price"],
            time_in_force=args.time_in_force,
        )
    except BinanceAPIError as exc:
        print(red(f"\n✗ Binance API error [{exc.code}]: {exc.message}\n"))
        logger.error("Binance API error: code=%s msg=%s", exc.code, exc.message)
        return 1
    except requests.exceptions.ConnectionError:
        msg = "Network connection failed. Check your internet connection and the testnet URL."
        print(red(f"\n✗ {msg}\n"))
        logger.error(msg)
        return 1
    except requests.exceptions.Timeout:
        msg = "Request timed out. The testnet may be slow; try again."
        print(red(f"\n✗ {msg}\n"))
        logger.error(msg)
        return 1
    except requests.exceptions.RequestException as exc:
        print(red(f"\n✗ HTTP error: {exc}\n"))
        logger.error("HTTP error: %s", exc)
        return 1
    except ValueError as exc:
        print(red(f"\n✗ Order error: {exc}\n"))
        logger.error("Order error: %s", exc)
        return 1

    # ── 5. Display result ───────────────────────────────────────────────────
    print_order_response(result)
    print(green("  ✓ Order placed successfully!\n"))
    logger.info("Order completed successfully: %s", json.dumps(result, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
